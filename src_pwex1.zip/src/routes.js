
import {BrowserRouter, Routes, Route} from 'react-router-dom'
import IMC from './pages/IMC'
import Header from './Componentes/Header'

function RouterApp() {
    return (
        <div>
            <BrowserRouter>
                <Header />
                <Routes>
                    <Route path='/' element={<IMC />}/>
                </Routes>
            </BrowserRouter>
        </div>
    );
}
export default RouterApp;