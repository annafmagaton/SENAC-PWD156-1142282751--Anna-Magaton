

/** -----------------------------------------*
 * SENAC - TADS - PROGRAMAÇÃO WEB - TURMA A  *
 * AVALIAÇÃO  Exercício 1 - IMC              *
 *-------------------------------------------*
 * Nome: Anna Paula Frassom da Silva Magaton *
 * Nome: Denise de Oliveira Mello            * 
 *-------------------------------------------*/
 
 import RouterApp from './routes'

 function App() {
   return (
     <RouterApp />
   );
 }
 export default App;
