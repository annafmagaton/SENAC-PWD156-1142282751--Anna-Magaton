
function Home() {
    return (
        <div class='row'>
            <div class='column'>
                <div class='card'>
                    <h1>BEM VINDO A HOME</h1>
                    <h2>Esta é a Home do nosso Bank TAD</h2>
                    <img src={require('./fotobanco.png')} alt='Foto do Bank TAD'></img>
                    </div>
                </div>
            </div>
    )
}
export default Home;
