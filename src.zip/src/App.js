
/** -----------------------------------------*
 * SENAC - TADS - PROGRAMAÇÃO WEB            *
 * ADO#2 Trabalhando as Rotas e LINKS        *
 *-------------------------------------------*
 * Nome: Anna Paula Frassom da Silva Magaton * 
 *-------------------------------------------*/
 

import RouterApp from './routes'

function App() {
  return (
    <RouterApp />
  );
}
export default App;
