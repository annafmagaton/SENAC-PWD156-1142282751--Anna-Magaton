import Header from "./header";

function CalculoFrete() {
    return (
        <div>
            <Header />
            <ul className="form-style-1">
                <li>
                    <label><h2>Cálculo de Frete</h2></label>
                </li>
                <li>
                    <label>Peso</label>
                    <input type="number" id="txtPeso" className="field-long" />
                </li>
                <li>
                    <label>Destino</label>
                    <input type="text" id="txtDestino" className="field-long" />
                </li>
                <li>
                    <input type="button" value="Calcular" onClick={calcular} />
                </li>
                <li id="res"></li>
            </ul>
        </div>
    )
}
function calcular() {

    const destinos = [{ cidade: 'São José do Rio Preto', distancia: 446 },
    { cidade: 'Campo Grande', distancia: 950 },
    { cidade: 'São Manuel', distancia: 230 }];
    const valorTonelada = 2.5;

    var p = document.getElementById('txtPeso');
    var d = document.getElementById('txtDestino');
    var peso = p.value;
    var destino = d.value;
    let res = document.getElementById('res')

    if (isNaN(peso) || peso === 0.0 || destino === "") {
        window.alert('[erro] Faltam dados a serem preenchidos!')
        return;
    }
    if (!window.confirm('Dados preenchidos corretamente?')) {
        return;
    }

    var destinoEncontrado = destinos.filter(function (item) {
        return item.cidade === destino;
    });

    if (destinoEncontrado.length === 0) {
        window.alert('[erro] Destino inválido');
        return;
    }

    var valorFrete = destinoEncontrado[0].distancia * valorTonelada;

    res.innerHTML = `<div class="resultado">
                    <label>Destino: ${destino}</label>
                    <label>Peso: ${peso}</label>
                    <label>Valor do Frete: ${valorFrete.toFixed(2)}</label>
                    </div>`

}

export default CalculoFrete;