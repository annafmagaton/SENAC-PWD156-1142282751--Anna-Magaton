import mainLogo from './logo.png';
import Header from './header';

function Home() {
    return (
        <div>
            <Header />
            <ul className="form-style-1">
                <li>
                    <label><h2>Bem vindo ao Sistema de Transporte Rodoviário Bananeira</h2></label>
                </li>
                <li className="logo">
                    <img src={mainLogo} alt="logo" />
                </li>
            </ul>
        </div>
    )
}
export default Home;