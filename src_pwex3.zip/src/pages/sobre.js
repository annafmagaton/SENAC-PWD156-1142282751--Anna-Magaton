import frotaLogo from './frota.webp';
import Menu from './header';

function Sobre() {
    return (
        <div>
            <Menu />
            <ul className="form-style-1">
                <li>
                    <label><h2>Sobre Nós</h2></label>
                    <p>A empresa Transporte Rodoviário Bananeira, é uma empresa presente no mercado desde 1986,
                        na qual, possui imensa credibilidade, devido aos serviços prestados. Serviços estes,
                        dos quais, passam a nossos clientes muita segurança, conforto, comodidade, modernidade
                        e preços diferenciados. Possuímos mais de 500 empresas clientes, assim como, prestamos
                        serviços de locomoção para pessoas físicas.
                        Bananeira Transporte Rodoviário a empresa que todos precisam! </p>
                </li>
                <li className="logo">
                    <img src={frotaLogo} alt="frotaLogo" />
                </li>
            </ul>
        </div>
    )
}
export default Sobre;