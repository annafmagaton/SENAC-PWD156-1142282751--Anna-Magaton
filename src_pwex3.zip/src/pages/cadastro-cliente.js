import Header from "./header";

function CadastroCliente() {
    return (
        <div>
            <Header />
            <ul className="form-style-1">
                <li>
                    <label><h2>Cadastro de Cliente</h2></label>
                </li>
                <li>
                    <label>Razão Social</label>
                    <input type="text" id="txtRazaoSocial" className="field-long" />
                </li>
                <li>
                    <label>Endereço</label>
                    <input type="text" id="txtEndereco" className="field-long" />
                </li>
                <li>
                    <label>CNPJ</label>
                    <input type="number" id="txtCnpj" className="field-long" />
                </li>
                <li>
                    <input type="button" value="Cadastrar" onClick={cadastrar} />
                </li>
                <li id="res"></li>
            </ul>
        </div>
    )
}
function cadastrar() {
    var r = document.getElementById('txtRazaoSocial');
    var e = document.getElementById('txtEndereco');
    var c = document.getElementById('txtCnpj');
    var razaoSocial = r.value;
    var endereco = e.value;
    var cnpj = c.value;
    let res = document.getElementById('res')

    if (razaoSocial === '' || endereco === '' || cnpj === '' || isNaN(cnpj)) {
        window.alert('[erro] Faltam dados a serem preenchidos!')
        return;
    }
    if (!window.confirm('Dados preenchidos corretamente?')) {
        return;
    }

    res.innerHTML = `<div class="resultado">
                        <label>Razão Social: ${razaoSocial}</label>
                        <label>Endereço: ${endereco}</label>
                        <label>CNPJ: ${cnpj}</label>
                    </div>`

}

export default CadastroCliente;