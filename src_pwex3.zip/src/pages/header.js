import { Link } from "react-router-dom";

function Header() {
    return (
        <header>
            <ul>
                <li style={{ float: "left" }}><Link to='/home'>Transporte Rodoviário Bananeira</Link></li>
                <div style={{ float: "right" }}>
                    <li><Link to='/home'>Home</Link></li>
                    <li><Link to='/cadastro-cliente'>Cadastro Cliente</Link></li>
                    <li><Link to='/calculo-frete'>Calculo Frete</Link></li>
                    <li><Link to='/sobre'>Sobre Nós</Link></li>
                    <li><Link to='/login'>Sair</Link></li>
                </div>
            </ul>
        </header>
    )
}
export default Header;