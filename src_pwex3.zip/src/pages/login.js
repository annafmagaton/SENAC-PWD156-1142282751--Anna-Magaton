import { useNavigate } from 'react-router-dom';

function Login() {
    const navigate = useNavigate();

    return (
        <div>
            <ul className="form-style-1">
                <li>
                    <label><h1>Transporte Rodoviário Bananeira</h1></label>
                </li>
                <li>
                    <label><h2>Entrada no Sistema</h2></label>
                </li>
                <li>
                    <label>ID</label>
                    <input type="text" id="txtID" className="field-long" />
                </li>
                <li>
                    <label>Senha</label>
                    <input type="password" id="txtSenha" className="field-long" />
                </li>
                <li>
                    <input type="button" value="Entrar no Sistema" onClick={logar} />
                </li>
            </ul>
        </div>
    )


    function logar() {
        const usuarios = [{ id: 'admin', senha: 'admin' },
        { id: 'anna', senha: 'anna' },
        { id: 'convidado', senha: 'convidado' }];

        var txtId = document.getElementById('txtID');
        var txtSenha = document.getElementById('txtSenha');

        var id = txtId.value;
        var senha = txtSenha.value;

        if (id === '' || senha === '') {
            window.alert('[erro] Faltam dados a serem preenchidos!')
            return;
        }

        if (!window.confirm('Dados preenchidos corretamente?')) {
            return;
        }

        var usuarioEncontrado = usuarios.filter(function (item) {
            return item.id === id;
        });

        if (usuarioEncontrado.length === 0) {
            window.alert('[erro] Usuário inválido');
            return;
        }

        var loginValido = usuarioEncontrado[0].senha === senha;

        if (!loginValido) {
            window.alert('[erro] Senha inválida');
            return;
        }

        navigate('/home');

    }
}
export default Login;