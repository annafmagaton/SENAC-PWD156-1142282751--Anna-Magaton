import { BrowserRouter, Routes, Route } from 'react-router-dom'
import CadastroCliente from './pages/cadastro-cliente';
import Home from './pages/home';
import Sobre from './pages/sobre';
import Login from './pages/login';
import CalculoFrete from './pages/calculo-frete';

function RoutesApp() {
    return (
        <div>
            <BrowserRouter>
                <Routes>
                    <Route path='/' element={< Login />} />
                    <Route path='/login' element={< Login />} />
                    <Route path='/home' element={< Home />} />
                    <Route path='/cadastro-cliente' element={< CadastroCliente />} />
                    <Route path='/calculo-frete' element={< CalculoFrete />} />
                    <Route path='/sobre' element={< Sobre />} />
                </Routes>
            </BrowserRouter>
        </div>
    );
}
export default RoutesApp;