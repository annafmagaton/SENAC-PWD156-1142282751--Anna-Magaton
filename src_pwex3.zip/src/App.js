/** ----------------------------------------- *
* SENAC - TADS - Programacao Web              *
* Avaliação PW - Exercício 3                  *
* ------------------------------------------- *
* Nome : Anna Paula Frassomm da Silva Magaton *
* Nome: Denise de Oliveira Melo               *
* ------------------------------------------- */
import './App.css';
import RoutesApp from './routes';

function App() {
  return (
    <div>
      <RoutesApp />
    </div>
  );
}

export default App;
